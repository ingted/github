﻿namespace ClickHouse.Ado.Impl.Data
{
    public enum HttpMethod
    {
        Unknown = 0,
        Get = 1,
        Post = 2,
    };
}