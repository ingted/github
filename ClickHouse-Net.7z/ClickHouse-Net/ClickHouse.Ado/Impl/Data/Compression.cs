﻿namespace ClickHouse.Ado.Impl.Data
{
    internal enum Compression
    {
        Disable = 0,
        Enable = 1,
    }
}