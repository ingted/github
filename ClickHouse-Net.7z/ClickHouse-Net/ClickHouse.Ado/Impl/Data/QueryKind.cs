﻿namespace ClickHouse.Ado.Impl.Data
{
    internal enum QueryKind
    {
        None=0,
        Initial=1,
        Secondary=2
    }
}