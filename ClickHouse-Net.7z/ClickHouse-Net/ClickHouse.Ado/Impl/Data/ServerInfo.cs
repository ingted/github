﻿namespace ClickHouse.Ado.Impl.Data
{
    public class ServerInfo
    {
        public long Major, Minor, Build;
        public string Name,Timezone;
    }
}