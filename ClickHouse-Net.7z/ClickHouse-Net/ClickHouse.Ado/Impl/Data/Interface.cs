﻿namespace ClickHouse.Ado.Impl.Data
{
    public enum Interface
    {
        Tcp = 1,
        Http = 2,
    };
}