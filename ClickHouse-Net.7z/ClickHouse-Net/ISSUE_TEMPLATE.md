## Description
... provide some general description of what has gone wrong or what you're proposing ...

## Steps to reproduce
1. You should include database structure as one of the steps (just CREATE commands you user to create relevant tables and some data suitable for test)
1. The second most important thing is SQL commands you run through the driver that gives trouble
1. And lastly, you could include some code that reproduces error
1. Anyway you may not follow these steps if you feel they're not relevant to your issue

## Workarounds
... if you know some workaround for the issue, provide it here ...

## What should be done
... if you know what should be done to mitigate the issue, provide it here ...
