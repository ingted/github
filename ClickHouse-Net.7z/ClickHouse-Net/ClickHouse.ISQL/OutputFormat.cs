﻿namespace ClickHouse.Isql
{
    public enum OutputFormat
    {
        TSV,
        TSVWithHeader,
        XML,
        //JSON
    }
}